# Handoff: Calino VJOURNAL Integration

## Overview

This handoff documents the design for integrating **VJOURNAL** support (RFC 5545) into Calino — a calendar app. VJOURNAL is the iCalendar component for freeform journal entries: date-stamped diary notes attached to a calendar day. They are distinct from VEVENT (scheduled events) and VTODO (tasks): no time, no duration, no completion state.

The integration spans two surfaces:
1. **Month view** — a subtle per-cell indicator and right-click entry point
2. **Journal view** — a dedicated full-page diary-style list view (new tab alongside Tasks)

---

## About the Design Files

The bundled HTML files are **design references** — high-fidelity prototypes showing intended look, layout, and behaviour. They are **not** production code to copy directly. The task is to recreate these designs inside Calino's existing codebase using its established patterns, component library, and data layer.

**Fidelity:** High-fidelity. Colours, typography, spacing, and interaction patterns are final. Implement pixel-accurately against Calino's existing design system.

---

## Design Tokens (Calino Design System)

All values are defined as CSS custom properties on `.calino`:

| Token | Value | Usage |
|---|---|---|
| `--canvas` | `#faf8f3` | App background (warm paper) |
| `--panel` | `#ffffff` | Cards, modals, toolbar |
| `--side` | `#f6f3ed` | Sidebar background |
| `--ink` | `#2c2823` | Primary text |
| `--ink-2` | `#6f6a62` | Secondary text |
| `--ink-3` | `#a39d93` | Placeholder, muted |
| `--line` | `rgba(44,40,33,0.09)` | Borders, dividers |
| `--line-2` | `rgba(44,40,33,0.05)` | Subtle cell dividers |
| `--accent` | `#b07d4f` | Brand amber (today, CTAs) |
| `--accent-soft` | `#efe7db` | Soft accent backgrounds |

**Typography:**
- Headings / dates: `Newsreader` (Google Fonts, `opsz` 6–72, weights 400/500/600)
- Body / UI: `-apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif`
- `-webkit-font-smoothing: antialiased` everywhere

---

## Feature Flag: Journal Enabled/Disabled

**Journal is disabled by default.** It must be explicitly enabled before any journal UI appears anywhere in the app.

### Enabling conditions
1. **Auto-enable on calendar import** — when adding a calendar (CalDAV, ICS file, etc.), scan the data for `VJOURNAL` components. If any exist, prompt the user: *"This calendar contains journal entries. Enable the Journal feature?"* and enable if they confirm.
2. **Settings toggle** — in Settings → General (or a dedicated "Features" section): a toggle labelled **"Journal"** with a short description: *"Attach freeform notes to calendar days."* Default: off.
3. **Command palette action** — an action `"Enable Journal"` / `"Disable Journal"` toggleable from the command bar (⌘K).

### What enabling does
- Shows the **Journal tab** in the main toolbar alongside Month / Week / Day / Agenda / Tasks
- Shows **journal indicators** (pen dots) on calendar cells that have entries
- Adds **"New Journal Entry"** to the right-click context menu on calendar cells
- Shows journal entries in the **Agenda view** (future work — see below)

### What disabling does
- Hides all of the above surfaces
- Does **not** delete any entry data — entries are preserved and will reappear if re-enabled

---

## Data Model

A journal entry maps to a `VJOURNAL` iCalendar component:

```typescript
interface JournalEntry {
  uid: string;           // Unique ID (RFC 5545 UID)
  dtstart: CalendarDate; // The date this entry is for (no time component)
  summary?: string;      // Optional title/headline
  description: string;   // Body text — supports Markdown (see below)
  created: Date;         // Creation timestamp
  lastModified: Date;    // Last edit timestamp
  calendarId: string;    // Which calendar this belongs to
}
```

Multiple entries per date are supported. A date can have 0, 1, or many entries. The cell indicator remains a single pen icon regardless of count — the count is communicated only inside the day modal.

---

## Surface 1: Month View Cell Indicator

### Anatomy

Each day cell in the month grid has a **header row** containing the date number and an optional journal indicator button:

```
┌─────────────────────┐
│  [30]          [✏]  │  ← cell-head: date number + pen indicator
│                     │
│  [event chip]       │
│  [task chip]        │
└─────────────────────┘
```

### Journal indicator button

- **Visibility when entry exists, no hover:** Always visible. A small **3–4px filled dot** in `--ink-3` (`#a39d93`) centered below the pen icon position. Subtle — communicates presence without demanding attention.  
  > ⚠️ **Spec delta from prototype:** The prototype shows an amber dot. The final spec is **grey (`--ink-3`)** — more subtle, less alarming. Only the pen icon on hover takes on the accent colour.
- **Visibility on cell hover:** Dot fades out, **pen SVG icon appears** at `--ink-3`, 12×12px, in a 20×20px rounded hit area.
- **Indicator hover state:** Background `color-mix(in srgb, var(--accent) 10%, transparent)`, icon colour `--accent`.
- **Indicator click:** Opens the **Day Modal** for that date.
- **No entry on this date:** Indicator is not rendered at all.
- **Position:** `margin-left: auto` within the cell-head flex row — pushed to the right of the date number.

### Pen icon SVG
```svg
<svg viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.5"
     stroke-linecap="round" stroke-linejoin="round">
  <path d="M9.5 2.5l2 2L4 12H2v-2L9.5 2.5z"/>
  <path d="M7.5 4.5l2 2"/>
</svg>
```

---

## Surface 2: Right-click Context Menu

Right-clicking any day cell opens a context menu at the cursor position.

### Items
```
┌─────────────────────────┐
│ 📅  New Event            │
│ ✓   New Task             │
│ ─────────────────────── │
│ ✏   New Journal Entry    │  ← amber colour, --accent
└─────────────────────────┘
```

### Spec
- Container: `background: --panel`, `border: 1px solid --line`, `border-radius: 11px`, `padding: 5px`, `min-width: 188px`
- Shadow: `0 8px 24px rgba(44,40,33,.13), 0 2px 6px rgba(44,40,33,.07)`
- Entrance animation: scale from `0.96` + `translateY(-4px)` → `1` + `translateY(0)`, `opacity: 0 → 1`, duration `130ms`
- Items: `height: 34px`, `border-radius: 7px`, `font-size: 13.5px`, icon `14×14px`
- "New Journal Entry" item: `color: --accent`, icon `color: --accent`, hover `background: color-mix(in srgb, var(--accent) 7%, transparent)`
- Dismiss: click outside, Esc, or item selection

**"New Journal Entry" action:** opens the **Compose Modal** for that date.  
**"New Event" / "New Task":** wire to existing event/task creation flows.

---

## Surface 3: Day Modal (View)

Opens when clicking the pen indicator on a cell that has entries. Shows **all entries for that date** stacked vertically.

### Layout (CSS Grid, 2 columns)
```
┌──────────────────────────────────────────────────────┐
│                                                  [×] │
│  [datecol 80px]   [content]                          │
│                                                      │
│   Friday           ─── rule ───                     │
│   30               Entry 1 summary (bold, 17px)     │
│   May 2026                                          │
│                    Entry 1 body paragraph...        │
│                    Entry 1 body paragraph...        │
│                                                      │
│                         · · ·                        │
│                                                      │
│                    Entry 2 summary                   │
│                    Entry 2 body...                   │
│                                                      │
│                    [+ Add entry]                     │
└──────────────────────────────────────────────────────┘
```

### Spec

**Scrim/overlay:**
- `background: rgba(44,40,33,.45)`, `backdrop-filter: blur(6px)`
- Entrance: `opacity: 0 → 1`, `200ms ease`

**Panel:**
- `width: 520px`, `max-width: calc(100vw - 40px)`
- `background: #fff`, `border-radius: 18px`, `padding: 36px 40px 40px`
- `border: 1px solid rgba(44,40,33,.09)`
- Shadow: `0 24px 64px rgba(44,40,33,.18), 0 4px 12px rgba(44,40,33,.08)`
- Entrance animation: `translateY(10px) → translateY(0)`, `220ms cubic-bezier(.22,1,.36,1)`
- Grid: `grid-template-columns: 80px 1fr`, `gap: 0 28px`

**Date column (left):**
- Day number: `font-family: Newsreader`, `font-size: 52px`, `font-weight: 400`, `color: --ink`, `letter-spacing: -0.025em`, `font-variant-numeric: tabular-nums`
- Weekday: `font-size: 10px`, `font-weight: 700`, `letter-spacing: .1em`, `text-transform: uppercase`, `color: --ink-3`, `margin-top: 6px`
- Month + year: `font-size: 11px`, `color: --ink-3`, `margin-top: 3px`

**Entry separator (`· · ·`):**
- Centred in the content column, `color: --ink-3`, `font-size: 13px`, `letter-spacing: .25em`
- Padding: `8px 0 20px` top/bottom

**Entry summary (title):**
- `font-size: 17px`, `font-weight: 500`, `color: --ink`, `letter-spacing: -.015em`
- Hidden if empty

**Entry body:** Rendered as Markdown (see Markdown section below)
- Base: `font-size: 14px`, `color: --ink-2`, `line-height: 1.75`
- Paragraphs: `gap: 10px` between

**"+ Add entry" button:**
- Below all entries, `align-self: flex-start`
- `height: 32px`, `padding: 0 12px`, `border-radius: 9px`
- `border: 1px solid --line`, `background: transparent`, `color: --ink-2`, `font-size: 13px`
- Hover: border and text go to `--accent`, subtle accent background tint
- Action: close this modal, open Compose Modal for same date

**Close button:** `32×32px`, `border-radius: 9px`, `position: absolute`, top-right of panel

### Double-click to edit
**Double-clicking anywhere on a `.jm-entry` block** should transition that entry into an inline edit state (see Compose/Edit section below). The rest of the day modal remains visible; only the clicked entry becomes editable.

---

## Surface 4: Compose / Edit Modal

Used for both new entries (from context menu or "+ Add entry") and editing existing entries (from double-click in day modal).

### Layout
Same 2-column grid as the view modal. Date column is identical. Content column contains:

1. `<input>` — title, `font-size: 17px`, `font-weight: 500`, placeholder *"Title (optional)"*, borderless, with a `1px solid --line` bottom border
2. `<textarea>` or Markdown editor — body, `font-size: 14px`, `line-height: 1.75`, placeholder *"Write something…"*, min 5 rows
3. Hint text: `"⌘ Return to save · Esc to cancel"` — `font-size: 12px`, `color: --ink-3`
4. Action row: **Cancel** (ghost) + **Save entry** (filled amber) buttons, right-aligned

### Keyboard shortcuts
- `⌘ Return` (Mac) / `Ctrl+Enter` (Win): save
- `Esc`: cancel/discard

### Edit mode (from double-click)
- Pre-fill title input with existing `summary`
- Pre-fill body with existing `description` (raw Markdown, not rendered HTML)
- On save: update the existing entry in place, re-render the day modal with updated content
- On cancel: revert to view state for that entry

---

## Markdown Support

Entry **bodies** (`description` field) are stored as Markdown and rendered as HTML in the view modal and Journal list view.

### Supported syntax (minimum viable set)

| Markdown | Rendered as |
|---|---|
| `**bold**` | `<strong>` |
| `_italic_` or `*italic*` | `<em>` |
| `# Heading` through `### Heading` | `<h1>`–`<h3>` |
| `- item` / `* item` | `<ul><li>` |
| `1. item` | `<ol><li>` |
| `> quote` | `<blockquote>` |
| `` `code` `` | `<code>` |
| blank line | paragraph break |
| `---` | `<hr>` |

### Rendering styles (within `.jm-body` and `.je-body`)
- `<p>`: `font-size: 14px`, `color: --ink-2`, `line-height: 1.75`, `margin: 0`, `gap: 10px` between siblings
- `<strong>`: `color: --ink`, `font-weight: 600`
- `<em>`: `font-style: italic`
- `<h1>`–`<h3>`: `font-family: Newsreader`, `color: --ink`, progressively smaller, `margin-top: 16px`
- `<ul>`, `<ol>`: `padding-left: 20px`, `color: --ink-2`, `line-height: 1.7`
- `<blockquote>`: `border-left: 3px solid --line`, `padding-left: 12px`, `color: --ink-3`, `font-style: italic`
- `<code>`: `font-family: monospace`, `font-size: 13px`, `background: rgba(44,40,33,.06)`, `border-radius: 4px`, `padding: 1px 5px`
- `<hr>`: `border: none`, `border-top: 1px solid --line`, `margin: 16px 0`

### In the compose textarea
- Store raw Markdown; do not convert on save
- Optionally show a **live split-pane preview** (raw Markdown left, rendered right) if your editor infrastructure supports it, or a simple toggle button (Edit / Preview). This is a nice-to-have, not blocking.
- Recommended library: [marked.js](https://marked.js.org/) (lightweight) or your existing Markdown library if one is present in the codebase

---

## Surface 5: Journal List View (Journal Tab)

A dedicated full-page view replacing the calendar grid when the **Journal** tab is active. Shares the existing chrome (toolbar, sidebar with mini-calendar + task list).

### Layout
- Left sidebar: unchanged (mini-calendar, calendars, tasks)
- Main area: `max-width: 720px`, left-aligned, `padding: 0 36px 80px`

### Top bar
- Left: entry count — `"<n> entries"`, `font-size: 14px`, `color: --ink-2`
- Right: `"+ New entry"` button — amber filled, `height: 36px`, `border-radius: 10px`

### Month group (`<section class="jmonth">`)
One section per month, with a heading:
- `font-family: Newsreader`, `font-size: 12px`, `font-weight: 500`, `letter-spacing: .1em`, `text-transform: uppercase`, `color: --ink-3`
- `border-bottom: 1px solid --line`, `padding-bottom: 14px`

### Entry row (`.je`)
2-column grid: `grid-template-columns: 64px 1fr`, `gap: 0 28px`, `padding: 26px 0`, `border-bottom: 1px solid --line-2`

**Date column (left):**
- Day number: `Newsreader`, `38px`, weight `400`, `color: --ink`, `letter-spacing: -.02em`
- Weekday: `10px`, `700`, `letter-spacing: .1em`, `uppercase`, `color: --ink-3`, `margin-top: 5px`

**Content column (right):**
- Summary: `15.5px`, `weight 500`, `color: --ink`
- Body: Markdown rendered, same styles as above

### Double-click to edit
Double-clicking a `.je` entry in the list opens an inline compose state for that entry, within the list view (not a modal). The entry expands into an editable form (title input + Markdown textarea + Save/Cancel). On save, collapse back to rendered view.

### Mini-calendar indicators
Days with journal entries display a **3–4px dot** below the date number in the mini-calendar:
- `background: --accent`, `opacity: .45`
- On `is-today` cells: `background: #fff`, `opacity: .7`

---

## Settings

Add a **Journal** section to Settings (or add to the General section if no dedicated section exists):

```
Journal
───────────────────────────────────────────
Enable Journal   [toggle]   off by default
```

Toggle description: *"Attach freeform notes to days in your calendar."*

When toggled on: enable all journal UI surfaces.
When toggled off: hide all journal UI surfaces. Data is preserved.

---

## Command Palette

Add the following actions to the command palette:

| Action | Condition |
|---|---|
| `"Enable Journal"` | Journal is currently disabled |
| `"Disable Journal"` | Journal is currently enabled |
| `"New Journal Entry"` | Journal is enabled — opens compose for today |
| `"Open Journal"` | Journal is enabled — navigates to Journal tab |

---

## iCalendar / CalDAV Integration

When parsing a `.ics` file or syncing a CalDAV calendar:

1. Detect `VJOURNAL` components in the stream
2. Map fields:
   - `DTSTART` → `dtstart` (date only, no time)
   - `SUMMARY` → `summary`
   - `DESCRIPTION` → `description` (stored as-is; if existing data uses plain text, wrap as a plain paragraph)
   - `UID` → `uid`
   - `CREATED` → `created`
   - `LAST-MODIFIED` → `lastModified`
3. If any `VJOURNAL` found during import: prompt to enable Journal feature (see Feature Flag section)
4. When writing back to CalDAV: serialise `JournalEntry` as `VJOURNAL` with the same field mapping

---

## Files in This Package

| File | Purpose |
|---|---|
| `Calino Month View.html` | Month view with journal indicators, context menu, and day/compose modals |
| `Calino Journal.html` | Journal list view (full-page diary layout) |
| `calino/journal-month.js` | JS for month view: indicators, context menu, view modal, compose modal |
| `calino/journal.js` | JS for journal list view renderer |
| `calino/journal.css` | All journal styles: indicator, context menu, modals, list view, compose |
| `calino/render.js` | Modified base renderer — adds `data-date` to grid cells and `Journal` to nav tabs |
| `calino/data.js` | Sample data including `journal` entries map (for reference) |

---

## Known Design Decisions & Open Questions

| Decision | Notes |
|---|---|
| **Indicator colour is grey, not amber** | Prototype used amber; final spec is `--ink-3` grey for subtlety. Only the hover state uses accent colour. |
| **One pen per cell, regardless of entry count** | Count communicated only inside the day modal via stacked entries. No badge/counter on the indicator. |
| **Markdown stored as raw text** | Do not convert to HTML on save. Always store the Markdown source. |
| **Double-click to edit** | In day modal: entry transitions to inline edit in-place. In journal list: entry expands inline. No separate edit page. |
| **Agenda view** | Not designed yet. Suggested: journal entries appear as a prose row in the daily agenda, below events and tasks, with the pen icon prefix. |
| **Search** | Not designed. Journal entry bodies and summaries should be searchable via the command bar. |
| **Attachments / images** | Not in scope for this phase. |
| **Per-entry colour / calendar association** | Each entry belongs to a `calendarId`. The calendar's colour could tint the pen indicator dot, matching the existing event colour system. Not designed — open for implementation judgement. |

/* Calino — journal integration for month view
   • Adds a pen indicator to cell headers on days with entries
   • Right-click on any cell → context menu
   • Clicking the indicator → day modal (all entries for that date, stacked)
   • Multiple entries per day supported                                      */

(function () {

  /* ── Entry data — arrays per date ───────────────────────────────────── */
  const ENTRIES = {
    '2026-05-08': [
      { summary: '', body: "Slow day. The dentist appointment went fine — nothing alarming. Spent the afternoon reading and letting the week decompress.\n\nSometimes the absence of events is the thing worth noting." }
    ],
    '2026-05-15': [
      { summary: 'Lunch with Mom', body: "Two hours over pasta and wine. She's doing well — the new neighbourhood is quieter, which she appreciates. We talked about summer plans and whether it's finally time to sort out the house.\n\nShe asked about work. I tried to explain what I'm building. She said \"it sounds important\" in a way that meant it." }
    ],
    '2026-05-16': [
      { summary: 'Design Sprint — Day 1', body: "The sprint started strong. We got through problem framing faster than expected because everyone had done the prep reading. The How Might We session surfaced a few things I hadn't considered.\n\nBig theme emerging: users don't struggle with finding features — they struggle with knowing whether to trust the output. That reframe might change everything." }
    ],
    '2026-05-22': [
      { summary: 'Product Planning Workshop', body: "Six hours in a room mapping out the next quarter. Draining but necessary. The whiteboard filled up fast — features, dependencies, unknowns. We landed on a focus area everyone could agree on, which is rare.\n\nNote to self: bring the standing desk next time. Back is destroyed." }
    ],
    '2026-05-27': [
      { summary: 'Brunch with Friends', body: "Long, slow morning. We ended up at Cafe Rouge for nearly three hours. It's been a while since I've laughed that much.\n\nSarah has a new project she's excited about — can't say much yet, but clearly can't stop thinking about it. Walked home along the river. Good day." }
    ],
    '2026-05-30': [
      { summary: '', body: "Up early. The city was quiet at 6am — one of those still mornings where everything feels slightly more possible than usual." },
      { summary: 'Q1 Retrospective', body: "Wrapped up the retrospective with the team this afternoon. Three things stood out: everyone's enthusiasm about the new design direction, how much ground we covered despite the mid-quarter reorg, and a real feeling that Q2 has momentum.\n\nThe hardest conversation was about documentation — it keeps slipping. We agreed to treat it like any other ticket starting next sprint." }
    ],
  };

  const MON_LONG = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  const WD_LONG  = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

  const penSvg = `<svg viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9.5 2.5l2 2L4 12H2v-2L9.5 2.5z"/><path d="M7.5 4.5l2 2"/></svg>`;
  const plusSvg = `<svg viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M6 1v10M1 6h10"/></svg>`;

  /* ── Helpers ─────────────────────────────────────────────────────────── */
  function parseDate(s) {
    const [y, m, d] = s.split('-').map(Number);
    return new Date(y, m - 1, d);
  }

  function entryHtml(e, index, total) {
    const sep = index > 0 ? `<div class="jm-entry-sep"><span>· · ·</span></div>` : '';
    const sum = e.summary ? `<div class="jm-summary">${e.summary}</div>` : '';
    const paras = e.body.split('\n\n').map(p => `<p>${p.trim()}</p>`).join('');
    return `${sep}<div class="jm-entry">${sum}<div class="jm-body">${paras}</div></div>`;
  }

  /* ── Indicators ─────────────────────────────────────────────────────── */
  function addIndicators(host) {
    host.querySelectorAll('.cell[data-date]').forEach(cell => {
      const date = cell.dataset.date;
      if (!ENTRIES[date] || !ENTRIES[date].length) return;
      if (cell.querySelector('.cell-jind')) return;
      const head = cell.querySelector('.cell-head');
      if (!head) return;
      const btn = document.createElement('button');
      btn.className = 'cell-jind';
      btn.setAttribute('data-date', date);
      const count = ENTRIES[date].length;
      btn.title = count === 1
        ? (ENTRIES[date][0].summary || 'Journal entry')
        : `${count} journal entries`;
      btn.innerHTML = penSvg;
      head.appendChild(btn);
    });
  }

  /* ── View modal ─────────────────────────────────────────────────────── */
  function buildViewModal() {
    const el = document.createElement('div');
    el.className = 'jm-scrim';
    el.innerHTML = `
      <div class="jm-panel">
        <button class="jm-close" aria-label="Close">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M3 3l10 10M13 3L3 13"/></svg>
        </button>
        <div class="jm-datecol">
          <span class="jm-day"></span>
          <span class="jm-weekday"></span>
          <span class="jm-month"></span>
        </div>
        <div class="jm-content">
          <div class="jm-rule"></div>
          <div class="jm-entries"></div>
          <button class="jm-add-entry" data-add-entry>${plusSvg} Add entry</button>
        </div>
      </div>`;
    document.body.appendChild(el);
    el.addEventListener('click', e => { if (e.target === el) closeViewModal(el); });
    el.querySelector('.jm-close').addEventListener('click', () => closeViewModal(el));
    return el;
  }

  function openViewModal(scrim, composeScrim, host, dateIso) {
    const entries = ENTRIES[dateIso] || [];
    const d = parseDate(dateIso);
    scrim.querySelector('.jm-day').textContent     = d.getDate();
    scrim.querySelector('.jm-weekday').textContent = WD_LONG[d.getDay()];
    scrim.querySelector('.jm-month').textContent   = `${MON_LONG[d.getMonth()]} ${d.getFullYear()}`;
    scrim.querySelector('.jm-entries').innerHTML   = entries
      .map((e, i) => entryHtml(e, i, entries.length)).join('');

    // Wire the add-entry button for this specific date
    const addBtn = scrim.querySelector('[data-add-entry]');
    addBtn.onclick = () => {
      closeViewModal(scrim);
      openComposeModal(composeScrim, scrim, host, dateIso);
    };

    scrim.classList.add('is-open');
    document.body.style.overflow = 'hidden';
  }

  function closeViewModal(scrim) {
    scrim.classList.remove('is-open');
    document.body.style.overflow = '';
  }

  /* ── Compose modal ──────────────────────────────────────────────────── */
  function buildComposeModal() {
    const el = document.createElement('div');
    el.className = 'jm-scrim jm-compose-scrim';
    el.innerHTML = `
      <div class="jm-panel jm-compose-panel">
        <button class="jm-close" aria-label="Close">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M3 3l10 10M13 3L3 13"/></svg>
        </button>
        <div class="jm-datecol">
          <span class="jm-day"></span>
          <span class="jm-weekday"></span>
          <span class="jm-month"></span>
        </div>
        <div class="jm-content">
          <div class="jm-rule"></div>
          <input  class="jm-input-title" type="text"     placeholder="Title (optional)">
          <textarea class="jm-input-body"               placeholder="Write something…" rows="5"></textarea>
          <div class="jm-compose-hint">⌘ Return to save · Esc to cancel</div>
          <div class="jm-compose-actions">
            <button class="jm-btn-cancel">Cancel</button>
            <button class="jm-btn-save">Save entry</button>
          </div>
        </div>
      </div>`;
    document.body.appendChild(el);
    el.addEventListener('click', e => { if (e.target === el) closeComposeModal(el); });
    el.querySelector('.jm-close').addEventListener('click', () => closeComposeModal(el));
    el.querySelector('.jm-btn-cancel').addEventListener('click', () => closeComposeModal(el));
    return el;
  }

  let composeTargetDate = null;
  let composeViewScrim  = null;
  let composeHost       = null;

  function openComposeModal(scrim, viewScrim, host, dateIso) {
    composeTargetDate = dateIso;
    composeViewScrim  = viewScrim;
    composeHost       = host;
    const d = parseDate(dateIso);
    scrim.querySelector('.jm-day').textContent     = d.getDate();
    scrim.querySelector('.jm-weekday').textContent = WD_LONG[d.getDay()];
    scrim.querySelector('.jm-month').textContent   = `${MON_LONG[d.getMonth()]} ${d.getFullYear()}`;
    scrim.querySelector('.jm-input-title').value   = '';
    scrim.querySelector('.jm-input-body').value    = '';
    scrim.classList.add('is-open');
    document.body.style.overflow = 'hidden';
    setTimeout(() => scrim.querySelector('.jm-input-body').focus(), 80);
    scrim.querySelector('.jm-btn-save').onclick = () => saveEntry(scrim);
  }

  function closeComposeModal(scrim) {
    scrim.classList.remove('is-open');
    document.body.style.overflow = '';
  }

  function saveEntry(composeScrim) {
    const body = composeScrim.querySelector('.jm-input-body').value.trim();
    if (!body) { composeScrim.querySelector('.jm-input-body').focus(); return; }
    const summary = composeScrim.querySelector('.jm-input-title').value.trim();
    if (!ENTRIES[composeTargetDate]) ENTRIES[composeTargetDate] = [];
    ENTRIES[composeTargetDate].push({ summary, body });
    closeComposeModal(composeScrim);
    addIndicators(composeHost);
    // Return to the day view showing all entries
    openViewModal(composeViewScrim, composeScrim, composeHost, composeTargetDate);
  }

  /* ── Context menu ───────────────────────────────────────────────────── */
  function buildContextMenu() {
    const el = document.createElement('div');
    el.className = 'jctx';
    el.innerHTML = `
      <button class="jctx-item" data-action="event">
        <svg viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><rect x="1" y="2.5" width="12" height="10" rx="2"/><path d="M1 5.5h12M4.5 1v3M9.5 1v3"/></svg>
        New Event
      </button>
      <button class="jctx-item" data-action="task">
        <svg viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="7" cy="7" r="5.5"/><path d="M4.5 7l2 2L9.5 5"/></svg>
        New Task
      </button>
      <div class="jctx-sep"></div>
      <button class="jctx-item jctx-item--journal" data-action="journal">
        ${penSvg}
        New Journal Entry
      </button>`;
    document.body.appendChild(el);
    return el;
  }

  let ctxTargetDate = null;

  function showContextMenu(menu, x, y, dateIso) {
    ctxTargetDate = dateIso;
    const left = Math.min(x, window.innerWidth  - 208);
    const top  = Math.min(y, window.innerHeight - 148);
    menu.style.left = left + 'px';
    menu.style.top  = top  + 'px';
    menu.classList.add('is-open');
  }

  function hideContextMenu(menu) {
    menu.classList.remove('is-open');
    ctxTargetDate = null;
  }

  /* ── Boot ───────────────────────────────────────────────────────────── */
  document.addEventListener('DOMContentLoaded', function () {
    const host         = document.getElementById('app');
    const viewModal    = buildViewModal();
    const composeModal = buildComposeModal();
    const ctxMenu      = buildContextMenu();

    addIndicators(host);

    /* Indicator click → day view modal */
    host.addEventListener('click', function (e) {
      const ind = e.target.closest('.cell-jind');
      if (!ind) return;
      e.stopPropagation();
      openViewModal(viewModal, composeModal, host, ind.dataset.date);
    });

    /* Right-click → context menu */
    host.addEventListener('contextmenu', function (e) {
      const cell = e.target.closest('.cell[data-date]');
      if (!cell) return;
      e.preventDefault();
      hideContextMenu(ctxMenu);
      showContextMenu(ctxMenu, e.clientX, e.clientY, cell.dataset.date);
    });

    /* Context menu actions */
    ctxMenu.addEventListener('click', function (e) {
      const item = e.target.closest('[data-action]');
      if (!item) return;
      const date = ctxTargetDate;
      hideContextMenu(ctxMenu);
      if (item.dataset.action === 'journal' && date) {
        openComposeModal(composeModal, viewModal, host, date);
      }
    });

    document.addEventListener('click',       () => hideContextMenu(ctxMenu));
    document.addEventListener('contextmenu', () => hideContextMenu(ctxMenu), true);

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        closeViewModal(viewModal);
        closeComposeModal(composeModal);
        hideContextMenu(ctxMenu);
      }
      if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
        if (composeModal.classList.contains('is-open')) {
          e.preventDefault();
          saveEntry(composeModal);
        }
      }
    });
  });

})();

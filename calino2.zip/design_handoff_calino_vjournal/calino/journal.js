/* Calino — Journal renderer (VJOURNAL)
   Call window.renderCalino() first, then window.renderCalinoJournal().
   Mirrors the tasks.js pattern: takes over .cal-main, retitles, activates tab. */

(function () {

  const MON_LONG  = ['January','February','March','April','May','June',
                     'July','August','September','October','November','December'];
  const WD_SHORT  = ['SUN','MON','TUE','WED','THU','FRI','SAT'];

  const TODAY = (window.CALINO && window.CALINO.today) || '2026-05-30';

  /* ── Sample VJOURNAL entries ─────────────────────────────────────────── */
  let ENTRIES = [
    {
      id: 1, date: '2026-05-30',
      summary: 'Q1 Retrospective',
      body: "Wrapped up the retrospective with the team this afternoon. Three things stood out: everyone's enthusiasm about the new design direction, how much ground we covered despite the mid-quarter reorg, and a real feeling that Q2 has momentum.\n\nThe hardest conversation was about documentation — it keeps slipping. We agreed to treat it like any other ticket starting next sprint. We'll see if that sticks."
    },
    {
      id: 2, date: '2026-05-27',
      summary: 'Brunch with Friends',
      body: "Long, slow morning. We ended up at Cafe Rouge for nearly three hours. It's been a while since I've laughed that much.\n\nSarah has a new project she's excited about — can't say much yet, but clearly can't stop thinking about it. Walked home along the river. Good day."
    },
    {
      id: 3, date: '2026-05-22',
      summary: 'Product Planning Workshop',
      body: "Six hours in a room mapping out the next quarter. Draining but necessary. The whiteboard filled up fast — features, dependencies, unknowns. We landed on a focus area everyone could agree on, which is rare.\n\nNote to self: bring the standing desk next time. Back is destroyed."
    },
    {
      id: 4, date: '2026-05-16',
      summary: 'Design Sprint — Day 1',
      body: "The sprint started strong. We got through problem framing faster than expected because everyone had done the prep reading. The How Might We session surfaced a few things I hadn't considered.\n\nBig theme emerging: users don't struggle with finding features — they struggle with knowing whether to trust the output. That reframe might change everything."
    },
    {
      id: 5, date: '2026-05-15',
      summary: 'Lunch with Mom',
      body: "Two hours over pasta and wine. She's doing well — the new neighbourhood is quieter, which she appreciates. We talked about summer plans and whether it's finally time to sort out the house.\n\nShe asked about work. I tried to explain what I'm building. She said \"it sounds important\" in a way that meant it."
    },
    {
      id: 6, date: '2026-05-08',
      summary: '',
      body: "Slow day. The dentist appointment went fine — nothing alarming. Spent the afternoon reading and letting the week decompress.\n\nSometimes the absence of events is the thing worth noting."
    },
  ];

  let composing = false;
  let nextId = 100;

  /* ── Helpers ─────────────────────────────────────────────────────────── */
  function parse(s) {
    const [y, m, d] = s.split('-').map(Number);
    return new Date(y, m - 1, d);
  }

  function isoToday() {
    const d = parse(TODAY);
    return { day: d.getDate(), wd: WD_SHORT[d.getDay()] };
  }

  /* ── Entry HTML ──────────────────────────────────────────────────────── */
  function entryHtml(e) {
    const d   = parse(e.date);
    const day = d.getDate();
    const wd  = WD_SHORT[d.getDay()];
    const sum = e.summary
      ? `<div class="je-summary">${e.summary}</div>`
      : '';
    const paras = e.body
      .split('\n\n')
      .map(p => `<p>${p.trim()}</p>`)
      .join('');
    return (
      `<article class="je" data-id="${e.id}">` +
        `<div class="je-datecol">` +
          `<span class="je-day">${day}</span>` +
          `<span class="je-weekday">${wd}</span>` +
        `</div>` +
        `<div class="je-content">${sum}<div class="je-body">${paras}</div></div>` +
      `</article>`
    );
  }

  /* ── Compose HTML ────────────────────────────────────────────────────── */
  function composeHtml() {
    const { day, wd } = isoToday();
    return (
      `<div class="je-compose">` +
        `<div class="je-compose-datecol">` +
          `<span class="je-compose-day">${day}</span>` +
          `<span class="je-compose-wd">${wd}</span>` +
        `</div>` +
        `<div class="je-compose-fields">` +
          `<input type="text" placeholder="Title (optional)" data-compose-title>` +
          `<textarea placeholder="Write something…" data-compose-body rows="4"></textarea>` +
          `<div class="je-compose-hint">⌘ Return to save · Esc to cancel</div>` +
          `<div class="je-compose-actions">` +
            `<button class="je-cancel" data-jcancel>Cancel</button>` +
            `<button class="je-save" data-jsave>Save entry</button>` +
          `</div>` +
        `</div>` +
      `</div>`
    );
  }

  /* ── Page HTML ───────────────────────────────────────────────────────── */
  function pageHtml() {
    const sorted = [...ENTRIES].sort((a, b) => b.date.localeCompare(a.date));

    // Group by YYYY-MM
    const groups = [];
    const seen   = new Map();
    sorted.forEach(e => {
      const key = e.date.slice(0, 7);
      if (!seen.has(key)) { seen.set(key, []); groups.push(key); }
      seen.get(key).push(e);
    });

    const compose = composing ? composeHtml() : '';

    let body = '';
    if (groups.length === 0 && !composing) {
      body = (
        `<div class="jp-empty">` +
          `<strong>Nothing written yet</strong>` +
          `Start capturing your days — one entry at a time.` +
        `</div>`
      );
    } else {
      groups.forEach(key => {
        const [y, m] = key.split('-').map(Number);
        const label  = `${MON_LONG[m - 1]} ${y}`;
        body += (
          `<section class="jmonth">` +
            `<div class="jmonth-head">${label}</div>` +
            seen.get(key).map(entryHtml).join('') +
          `</section>`
        );
      });
    }

    const count = ENTRIES.length;
    return (
      `<div class="journal-page">` +
        `<div class="jp-inner">` +
          `<div class="jp-bar">` +
            `<div class="jp-count"><b>${count}</b> ${count === 1 ? 'entry' : 'entries'}</div>` +
            `<button class="add-entry" data-jadd>` +
              `<svg width="11" height="11" viewBox="0 0 11 11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M5.5 1v9M1 5.5h9"/></svg>` +
              `New entry` +
            `</button>` +
          `</div>` +
          compose +
          `<div class="jp-list">${body}</div>` +
        `</div>` +
      `</div>`
    );
  }

  /* ── Paint ───────────────────────────────────────────────────────────── */
  function paint(host) {
    host.querySelector('.cal-main').innerHTML = pageHtml();
    if (composing) {
      const ta = host.querySelector('[data-compose-body]');
      if (ta) ta.focus();
    }
    markMiniCal(host);
  }

  /* ── Mark mini-calendar days that have journal entries ───────────────── */
  function markMiniCal(host) {
    const journalDates = new Set(ENTRIES.map(e => e.date));
    const data = window.CALINO;
    if (!data) return;

    const { year, month } = data;
    const first = new Date(year, month, 1);
    // Start on the Monday before (or on) the 1st — same logic as render.js
    const start = new Date(first);
    start.setDate(1 - ((first.getDay() + 6) % 7));

    const cells = host.querySelectorAll('.mini-d');
    const cur   = new Date(start);
    cells.forEach(cell => {
      const iso =
        `${cur.getFullYear()}-` +
        `${String(cur.getMonth() + 1).padStart(2, '0')}-` +
        `${String(cur.getDate()).padStart(2, '0')}`;
      if (journalDates.has(iso)) cell.classList.add('has-journal');
      cur.setDate(cur.getDate() + 1);
    });
  }

  /* ── Save new entry ──────────────────────────────────────────────────── */
  function saveEntry(host) {
    const titleEl = host.querySelector('[data-compose-title]');
    const bodyEl  = host.querySelector('[data-compose-body]');
    const bodyTxt = bodyEl ? bodyEl.value.trim() : '';
    if (!bodyTxt) { if (bodyEl) bodyEl.focus(); return; }
    ENTRIES.unshift({
      id:      nextId++,
      date:    TODAY,
      summary: titleEl ? titleEl.value.trim() : '',
      body:    bodyTxt,
    });
    composing = false;
    paint(host);
  }

  /* ── Public ──────────────────────────────────────────────────────────── */
  window.renderCalinoJournal = function (host) {
    // 1. Retitle
    const titleLeft = host.querySelector('.title-left');
    if (titleLeft) titleLeft.innerHTML = `<h1 class="month-title">Journal</h1>`;

    // 2. Activate Journal tab
    host.querySelectorAll('.tabs .tab').forEach(b => {
      b.classList.toggle('is-active', b.textContent.trim() === 'Journal');
    });

    // 3. Render
    paint(host);

    // 4. Interactions (delegated — safe to add once)
    host.addEventListener('click', function onJClick(e) {
      if (e.target.closest('[data-jadd]'))     { composing = true;  paint(host); return; }
      if (e.target.closest('[data-jcancel]'))  { composing = false; paint(host); return; }
      if (e.target.closest('[data-jsave]'))    { saveEntry(host);                return; }
    });

    host.addEventListener('keydown', function onJKey(e) {
      if (e.key === 'Escape' && composing) { composing = false; paint(host); return; }
      if ((e.metaKey || e.ctrlKey) && e.key === 'Enter' && composing) {
        e.preventDefault();
        saveEntry(host);
      }
    });
  };

})();
